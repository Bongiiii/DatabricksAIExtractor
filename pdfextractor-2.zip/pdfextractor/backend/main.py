import os
import json
import uuid
import shutil
import traceback
import logging
import requests
from concurrent.futures import ThreadPoolExecutor
from typing import List, Optional, Dict, Any
from pathlib import Path

from fastapi import FastAPI, File, Form, UploadFile, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from dataExtractor import EnhancedPDFExtractor, UC_VOLUME_PATH

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(title="PDF Data Extractor", version="3.0.0")

FRONTEND_URL = os.getenv("DATABRICKS_APP_URL", "*")
app.add_middleware(
    CORSMiddleware,
    allow_origins=[FRONTEND_URL] if FRONTEND_URL != "*" else ["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

extractor = EnhancedPDFExtractor()
executor = ThreadPoolExecutor(max_workers=4)
job_store: Dict[str, Any] = {}


def ensure_temp_dirs():
    upload_dir = "/tmp/uploaded"
    extract_dir = "/tmp/extracted_tables"
    os.makedirs(upload_dir, exist_ok=True)
    os.makedirs(extract_dir, exist_ok=True)
    return upload_dir, extract_dir


def query_vision_model(base64_image: str, prompt: str) -> str:
    workspace_host = extractor.w.config.host.rstrip("/")
    endpoint_url = f"{workspace_host}/serving-endpoints/{extractor.vision_model}/invocations"
    auth_headers = extractor.w.config.authenticate()
    headers = {**auth_headers, "Content-Type": "application/json"}
    payload = {
        "messages": [
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": prompt},
                    {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{base64_image}"}},
                ],
            }
        ],
        "max_tokens": 1024,
        "temperature": 0.1,
    }
    resp = requests.post(endpoint_url, headers=headers, json=payload, timeout=60)
    resp.raise_for_status()
    return resp.json()["choices"][0]["message"]["content"].strip()


async def get_columns_from_pdf(pdf_path: str) -> List[str]:
    images = extractor.pdf_to_images(pdf_path, dpi=200)
    if not images:
        return []
    prompt = (
    "Look at this document image and find the main data table's column headers.\n\n"
    "Return ONLY a JSON array of the column header names.\n\n"
    "Rules:\n"
    "- Column headers are SHORT labels sitting at the TOP of table columns above rows of data\n"
    "- Reject any text that contains parentheses with numbers like '(34 species)' or 'including'\n"
    "- Reject category counts, document titles, and summary sentences\n"
    "- Valid headers look like: Status, Lead Region, Scientific name, Family, Common name\n"
    "- If no valid table headers found return []\n\n"
    'Example output: ["Category", "Trend", "Lead Region", "Scientific name", "Family", "Common name", "Historic range"]\n\n'
    "Return ONLY the JSON array, no explanation."
)
    for i, image in enumerate(images[:5]):
        base64_image = extractor.encode_image(image)
        response_text = query_vision_model(base64_image, prompt)
        cleaned = response_text.strip()
        if "```json" in cleaned:
            cleaned = cleaned.split("```json")[1].split("```")[0]
        elif "```" in cleaned:
            cleaned = cleaned.split("```")[1].split("```")[0]
        cleaned = cleaned.strip()
        if not cleaned.startswith("["):
            start = cleaned.find("[")
            end = cleaned.rfind("]") + 1
            if start != -1 and end > start:
                cleaned = cleaned[start:end]
        try:
            parsed = json.loads(cleaned)
            if isinstance(parsed, list) and len(parsed) > 0:
                logger.info(f"Detected columns on page {i+1}: {parsed}")
                return parsed
        except Exception as e:
            logger.warning(f"Page {i+1} column parse failed: {e}")
    return []


def _run_extraction(pdf_path, columns_list, extra_instructions, mode, dpi, page_ranges, sample_pages):
    return extractor.process_pdf_enhanced(
        pdf_path=pdf_path,
        columns=columns_list,
        extra_instructions=extra_instructions,
        mode=mode,
        dpi=dpi,
        page_ranges=page_ranges,
        sample_pages=sample_pages,
    )


def _create_job(filename):
    job_id = str(uuid.uuid4())
    job_store[job_id] = {"status": "running", "filename": filename}
    return job_id


def _finish_job(job_id, output_path, filename):
    job_store[job_id] = {
        "status": "done",
        "output_path": output_path,
        "filename": filename.replace(".pdf", "_extracted.xlsx"),
    }


def _fail_job(job_id, error):
    job_store[job_id] = {"status": "error", "error": error}


@app.get("/health")
async def health_check():
    issues = []
    try:
        workspace_host = extractor.w.config.host
    except Exception as e:
        workspace_host = None
        issues.append(f"WorkspaceClient error: {e}")

    sql_http_path = os.getenv("DATABRICKS_SQL_HTTP_PATH")
    if not sql_http_path:
        issues.append("DATABRICKS_SQL_HTTP_PATH not set")

    try:
        import pytesseract
        tess_version = str(pytesseract.get_tesseract_version())
    except Exception as e:
        tess_version = None
        issues.append(f"Tesseract not available: {e}")

    # volume access via SDK not filesystem
    volume_accessible = True
    try:
        list(extractor.w.files.list_directory_contents(UC_VOLUME_PATH))
    except Exception as e:
        volume_accessible = False
        issues.append(f"UC Volume SDK access failed: {e}")

    status = "healthy" if not issues else "degraded"
    response = {
        "status": status,
        "workspace": workspace_host,
        "sql_http_path_configured": bool(sql_http_path),
        "tesseract_version": tess_version,
        "uc_volume": UC_VOLUME_PATH,
        "uc_volume_accessible": volume_accessible,
        "models": {"vision": extractor.vision_model, "text": extractor.text_model},
        "extraction_methods": {
            "ai_parse_document": bool(sql_http_path),
            "tesseract_ocr": tess_version is not None,
            "vision_fallback": True,
        },
    }
    if issues:
        response["warnings"] = issues
    return JSONResponse(status_code=200 if status == "healthy" else 207, content=response)


@app.get("/test-vision")
async def test_vision(model: Optional[str] = None):
    test_model = model or extractor.vision_model
    try:
        tiny_png = (
            "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8"
            "z8BQDwADhQGAWjR9awAAAABJRU5ErkJggg=="
        )
        original = extractor.vision_model
        extractor.vision_model = test_model
        try:
            result = query_vision_model(tiny_png, "What do you see? Reply in one word.")
        finally:
            extractor.vision_model = original
        return {"status": "ok", "vision_model": test_model, "response": result}
    except requests.HTTPError as e:
        return JSONResponse(status_code=500, content={"status": "error", "http_status": e.response.status_code, "detail": e.response.text})
    except Exception as e:
        return JSONResponse(status_code=500, content={"status": "error", "error": str(e)})


@app.get("/test-sql")
async def test_sql_connection():
    try:
        conn = extractor._get_sql_connection()
        with conn.cursor() as cursor:
            cursor.execute("SELECT 1 AS ping")
            row = cursor.fetchone()
        conn.close()
        return {"status": "ok", "result": row[0] if row else None}
    except Exception as e:
        return JSONResponse(status_code=500, content={"status": "error", "message": str(e), "detail": traceback.format_exc()})


@app.get("/test-ocr")
async def test_ocr():
    try:
        import pytesseract
        return {"status": "ok", "tesseract_version": str(pytesseract.get_tesseract_version())}
    except Exception as e:
        return JSONResponse(status_code=500, content={"status": "error", "error": str(e)})


# sdk files.list — volume not mounted as filesystem in app container
@app.get("/volume-files")
async def list_volume_files():
    try:
        files = []
        for f in extractor.w.files.list_directory_contents(UC_VOLUME_PATH):
            if f.path.lower().endswith(".pdf"):
                files.append({
                    "name": Path(f.path).name,
                    "size_mb": round(f.file_size / (1024 * 1024), 2) if f.file_size else 0,
                    "path": f.path,
                })
        files.sort(key=lambda x: x["name"])
        logger.info(f"Listed {len(files)} PDF files in Volume")
        return {"files": files, "volume_path": UC_VOLUME_PATH}
    except Exception as e:
        logger.error(f"Error listing volume files: {traceback.format_exc()}")
        return JSONResponse(status_code=500, content={"error": str(e)})


@app.post("/autoparse_columns")
async def autoparse_columns(file: UploadFile = File(...)):
    upload_dir, _ = ensure_temp_dirs()
    temp_filename = os.path.join(upload_dir, f"{uuid.uuid4()}_{file.filename}")
    try:
        with open(temp_filename, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
        columns = await get_columns_from_pdf(temp_filename)
        return {"columns": columns}
    except Exception as e:
        logger.error(f"Error in autoparse_columns: {traceback.format_exc()}")
        return JSONResponse(status_code=500, content={"error": str(e)})
    finally:
        if os.path.exists(temp_filename):
            os.remove(temp_filename)


# sdk files.download — volume not mounted as filesystem
@app.get("/autoparse_columns_from_volume")
async def autoparse_columns_from_volume(filename: str):
    upload_dir, _ = ensure_temp_dirs()
    tmp_path = os.path.join(upload_dir, f"{uuid.uuid4()}_{filename}")
    try:
        response = extractor.w.files.download(f"{UC_VOLUME_PATH}/{filename}")
        with open(tmp_path, "wb") as f:
            f.write(response.contents.read())
        columns = await get_columns_from_pdf(tmp_path)
        return {"columns": columns}
    except Exception as e:
        logger.error(f"Error in autoparse_columns_from_volume: {traceback.format_exc()}")
        return JSONResponse(status_code=500, content={"error": str(e)})
    finally:
        if os.path.exists(tmp_path):
            os.remove(tmp_path)


@app.post("/extract")
async def extract_table(
    background_tasks: BackgroundTasks,
    file: UploadFile = File(...),
    columns: str = Form(...),
    extra_instructions: str = Form(""),
    mode: str = Form("scientific"),
    dpi: int = Form(200),
    page_ranges: Optional[str] = Form(None),
    sample_pages: Optional[int] = Form(None),
):
    upload_dir, _ = ensure_temp_dirs()
    logger.info(f"Extraction request – file: {file.filename}, columns: {columns}")

    if not file.filename.lower().endswith(".pdf"):
        return JSONResponse(status_code=400, content={"error": "Only PDF files are supported"})

    try:
        columns_list: List[str] = json.loads(columns)
        if not isinstance(columns_list, list) or len(columns_list) == 0:
            raise ValueError("columns must be a non-empty array")
    except (json.JSONDecodeError, ValueError) as e:
        return JSONResponse(status_code=400, content={"error": f"Invalid columns: {str(e)}"})

    job_id = _create_job(file.filename)
    temp_filename = os.path.join(upload_dir, f"{job_id}_{file.filename}")
    original_filename = file.filename

    with open(temp_filename, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)

    def run_job():
        logger.info(f"Job {job_id} started")
        try:
            output_path = _run_extraction(temp_filename, columns_list, extra_instructions, mode, dpi, page_ranges, sample_pages)
            _finish_job(job_id, output_path, original_filename)
            logger.info(f"Job {job_id} complete")
        except Exception as e:
            logger.error(f"Job {job_id} failed: {traceback.format_exc()}")
            _fail_job(job_id, str(e))
        finally:
            if os.path.exists(temp_filename):
                try:
                    os.remove(temp_filename)
                except Exception as ex:
                    logger.warning(f"Could not delete temp file: {ex}")

    background_tasks.add_task(run_job)
    return {"job_id": job_id, "status": "running"}


# sdk files.download — volume not mounted as filesystem
@app.post("/extract-from-volume")
async def extract_from_volume(
    background_tasks: BackgroundTasks,
    filename: str = Form(...),
    columns: str = Form(...),
    extra_instructions: str = Form(""),
    mode: str = Form("scientific"),
    dpi: int = Form(200),
    page_ranges: Optional[str] = Form(None),
    sample_pages: Optional[int] = Form(None),
):
    logger.info(f"Volume extraction request – file: {filename}, columns: {columns}")

    try:
        columns_list: List[str] = json.loads(columns)
        if not isinstance(columns_list, list) or len(columns_list) == 0:
            raise ValueError("columns must be a non-empty array")
    except (json.JSONDecodeError, ValueError) as e:
        return JSONResponse(status_code=400, content={"error": f"Invalid columns: {str(e)}"})

    job_id = _create_job(filename)

    def run_job():
        tmp_path = None
        logger.info(f"Volume job {job_id} started for {filename}")
        try:
            ensure_temp_dirs()
            tmp_path = f"/tmp/uploaded/{job_id}_{filename}"
            response = extractor.w.files.download(f"{UC_VOLUME_PATH}/{filename}")
            with open(tmp_path, "wb") as f:
                f.write(response.contents.read())
            output_path = _run_extraction(tmp_path, columns_list, extra_instructions, mode, dpi, page_ranges, sample_pages)
            _finish_job(job_id, output_path, filename)
            logger.info(f"Volume job {job_id} complete")
        except Exception as e:
            logger.error(f"Volume job {job_id} failed: {traceback.format_exc()}")
            _fail_job(job_id, str(e))
        finally:
            if tmp_path and os.path.exists(tmp_path):
                try:
                    os.remove(tmp_path)
                except Exception as ex:
                    logger.warning(f"Could not delete temp file: {ex}")

    background_tasks.add_task(run_job)
    return {"job_id": job_id, "status": "running"}


@app.get("/status/{job_id}")
async def job_status(job_id: str):
    job = job_store.get(job_id)
    if not job:
        return JSONResponse(status_code=404, content={"error": "Job not found"})
    if job["status"] == "error":
        return JSONResponse(status_code=500, content={"status": "error", "error": job["error"]})
    return {"status": job["status"], "job_id": job_id, "filename": job.get("filename", "")}


@app.get("/download/{job_id}")
async def download_result(job_id: str):
    job = job_store.get(job_id)
    if not job:
        return JSONResponse(status_code=404, content={"error": "Job not found"})
    if job["status"] != "done":
        return JSONResponse(status_code=202, content={"status": job["status"], "message": "Not ready yet"})
    if not os.path.exists(job["output_path"]):
        return JSONResponse(status_code=500, content={"error": "Output file missing"})
    return FileResponse(
        job["output_path"],
        filename=job["filename"],
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    )


if os.path.exists("frontend/build/static"):
    app.mount("/static", StaticFiles(directory="frontend/build/static"), name="static")
    logger.info("Mounted frontend static files")


@app.get("/")
async def read_index():
    index_path = "frontend/build/index.html"
    if os.path.exists(index_path):
        return FileResponse(index_path)
    return {"message": "Frontend not built – API docs at /docs"}


@app.get("/{rest_of_path:path}")
async def react_app(rest_of_path: str):
    if any(rest_of_path.startswith(p) for p in (
        "api/", "docs", "openapi.json", "health", "extract",
        "autoparse_columns", "test-ocr", "test-sql", "test-vision",
        "status/", "download/", "volume-files",
    )):
        return JSONResponse(status_code=404, content={"error": "Not found"})
    index_path = "frontend/build/index.html"
    if os.path.exists(index_path):
        return FileResponse(index_path)
    return {"message": "Frontend not built"}


if __name__ == "__main__":
    import uvicorn
    port = int(os.getenv("PORT", 8000))
    logger.info(f"Starting server on port {port}")
    uvicorn.run(app, host="0.0.0.0", port=port, timeout_keep_alive=300)